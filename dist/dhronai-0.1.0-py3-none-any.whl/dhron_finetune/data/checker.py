import json


def is_preprocessed(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        first_line = f.readline()

    try:
        data = json.loads(first_line)
        return data.get("__dhron_processed__") is True
    except:
        return False