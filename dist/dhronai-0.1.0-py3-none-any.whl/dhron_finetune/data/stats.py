import json
from transformers import AutoTokenizer


def compute_stats(file_path: str):
    tokenizer = AutoTokenizer.from_pretrained("gpt2")

    total = 0
    lengths = []

    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            sample = json.loads(line)

            text = (
                sample.get("instruction", "") + " " +
                sample.get("input", "") + " " +
                sample.get("output", "")
            )

            tokens = tokenizer.encode(text)
            lengths.append(len(tokens))
            total += 1

    if total == 0:
        return {
            "total": 0,
            "avg_tokens": 0,
            "max_tokens": 0,
        }

    return {
        "total": total,
        "avg_tokens": sum(lengths) / total,
        "max_tokens": max(lengths),
    }