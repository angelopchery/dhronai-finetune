def tokenize_function(example, tokenizer, max_length=512):
    return tokenizer(
        example["text"],
        truncation=True,
        padding="max_length",
        max_length=max_length,
    )