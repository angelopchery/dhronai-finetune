import json

REQUIRED_KEYS = {"instruction", "input", "output"}


def validate_jsonl(file_path):
    total = 0
    errors = 0

    with open(file_path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f, start=1):
            try:
                data = json.loads(line)

                # 🔥 Skip metadata line
                if data.get("__dhron_processed__"):
                    continue

                total += 1

                if not REQUIRED_KEYS.issubset(data.keys()):
                    print(f"❌ Line {i}: Missing fields")
                    errors += 1
                    continue

                if any(len(data[k].strip()) == 0 for k in REQUIRED_KEYS):
                    print(f"❌ Line {i}: Empty fields")
                    errors += 1

            except Exception:
                print(f"❌ Line {i}: Invalid JSON")
                errors += 1

    return total, errors