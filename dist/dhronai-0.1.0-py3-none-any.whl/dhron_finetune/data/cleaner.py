__all__ = ["normalize", "is_valid", "is_garbage"]

DEFAULT_INSTRUCTION = "Answer the question clearly and accurately."


def clean_text(text):
    if not isinstance(text, str):
        return ""
    return text.strip()


def is_garbage(sample):
    input_text = str(sample.get("input", ""))

    if "Generated question" in input_text:
        return True

    output_text = sample.get("output", "")
    if isinstance(output_text, str) and "qa_pairs" in output_text:
        return True

    return False


def normalize(sample):
    # fallback handling (VERY IMPORTANT for your dataset)
    input_text = clean_text(
        sample.get("input") or sample.get("question", "")
    )

    output_text = clean_text(
        sample.get("output") or sample.get("answer", "")
    )

    return {
        "instruction": DEFAULT_INSTRUCTION,
        "input": input_text,
        "output": output_text,
    }


def is_valid(sample):
    input_text = sample.get("input", "")
    output_text = sample.get("output", "")

    return (
        isinstance(input_text, str)
        and isinstance(output_text, str)
        and len(input_text.strip()) > 5
        and len(output_text.strip()) > 5
    )