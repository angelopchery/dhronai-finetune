import json
from datasets import Dataset


def load_jsonl_dataset(file_path: str):
    records = []

    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            data = json.loads(line)

            # 🔥 skip metadata line
            if data.get("__dhron_processed__"):
                continue

            records.append(data)

    return Dataset.from_list(records)